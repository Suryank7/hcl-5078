package org.abes.hrmsdatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmsdatabseApplicationTests {

    @Test
    void contextLoads() {
    }

}
